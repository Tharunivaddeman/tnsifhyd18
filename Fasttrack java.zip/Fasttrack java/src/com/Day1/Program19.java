package com.Day1;
import java.util.*;
public class Program19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number:");
		int num=sc.nextInt();
		System.out.println("enter the  ");

	}

}
