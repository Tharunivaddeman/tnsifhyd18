package com.Day1;
import java.util.*;

public class Program4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int count=1;
		System.out.println("Enter a number to find prime or not:");
		int num=sc.nextInt();
		if(num==0||num==1) {
			System.out.println(num+" is not a prime number");
		}
		for(int i=2;i<=num;i++) {
			if(num%i==0) {
				count++;
			}
		}
		if(count==2) {
			System.out.println(num+" is a prime number");
		}
		else {
			System.out.println(num+" is not a prime number");
		}

	}

}
