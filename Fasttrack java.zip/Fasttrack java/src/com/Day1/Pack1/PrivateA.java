package com.Day1.Pack1;

public class PrivateA {
	
	private void display()
	{
	System.out.println("TNS Sessions");
	}
}
