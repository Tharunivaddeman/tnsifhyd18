package com.Day1.Pack1;

public class PublicA {
	
	public void display() {
		System.out.println("TNS Sessions");
	}

}
