package com.Day1.Pack1;

public class PrivateMain {
	
	public static void main(String[] args) {
		PrivateA a1 = new PrivateA();
		a1.display();
	}

}
