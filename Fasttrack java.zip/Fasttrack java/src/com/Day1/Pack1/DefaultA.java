package com.Day1.Pack1;

public class DefaultA {
	
	void display() {
		System.out.println("TNS sessions");
	}

}
