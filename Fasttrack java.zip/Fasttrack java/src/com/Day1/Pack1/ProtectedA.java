package com.Day1.Pack1;

public class ProtectedA {
	
	protected void display() {
		System.out.println("TNS Sessions");
	}

}
